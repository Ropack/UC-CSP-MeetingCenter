﻿namespace UC.CSP.MeetingCenter.DAL.Entities
{
    public interface IValidatable
    {
        void Validate();
    }
}