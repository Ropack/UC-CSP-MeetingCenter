﻿using System;

namespace UC.CSP.MeetingCenter.DAL.Entities
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}