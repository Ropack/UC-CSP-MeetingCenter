﻿using System;

namespace UC.CSP.MeetingCenter.APP
{
    public enum FormMode
    {
        New = 1,
        Edit = 2
    }
}
