﻿namespace UC.CSP.MeetingCenter.BL.Services
{
    public interface IStorageProvider
    {
        void Save();
        void Load();
    }
}